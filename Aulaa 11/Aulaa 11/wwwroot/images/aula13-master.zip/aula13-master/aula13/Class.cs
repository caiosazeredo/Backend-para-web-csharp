﻿namespace Escola
{
    
    public class Professor
    {
        public string ImagemUrl { get; set; } = string.Empty; // URL da imagem do filme
        public string Descricao { get; set; } = string.Empty; // Descrição do filme
    }
}

