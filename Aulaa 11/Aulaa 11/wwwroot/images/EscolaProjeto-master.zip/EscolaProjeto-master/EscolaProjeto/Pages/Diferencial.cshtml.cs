using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EscolaProjeto.Pages
{
    public class DiferenciaisModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
