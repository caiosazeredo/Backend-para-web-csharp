using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EscolaProjeto.Pages
{
    public class LocalizacaoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
