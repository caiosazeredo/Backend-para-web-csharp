﻿namespace EscolaProjeto.Models
{
    public class EscolaInfo
    {
        public string Nome { get; set; }
        public string Endereco { get; set; }
    }
}